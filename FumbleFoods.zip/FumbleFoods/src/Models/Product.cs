﻿using FumbleFoods.src.Models;
using static System.Net.Mime.MediaTypeNames;

public class Product
{
    public int productId { get; set; }
    public Manufacturer manufacturer { get; set; }
    public string productName { get; set; }
    public string description { get; set; }
    public decimal cost { get; set; }
    public string image { get; set; }
    public decimal weight { get; set; }
    public string SKU { get; set; }
    public int inventory { get; set; }
    public string dimensions { get; set; }
    public decimal rating { get; set; }
    public string category { get; set; }
}
