﻿using FumbleFoods.src.Models;
using Microsoft.EntityFrameworkCore;
using poggers.src.Models;

namespace FumbleBE.src.Data
{
    public class FumbleDbContext : DbContext
    {
        public FumbleDbContext(DbContextOptions<FumbleDbContext> options) : base(options) { }

        public DbSet<User> User { get; set; }
        public DbSet<Product> Product { get; set; }

    }
}
