﻿using FumbleFoods.src.Models;
using Microsoft.EntityFrameworkCore;

namespace FumbleBE.src.Data
{
    public class FumbleDbContext : DbContext
    {
        public FumbleDbContext(DbContextOptions<FumbleDbContext> options) : base(options) { }

        public DbSet<User> User { get; set; }
        public DbSet<Product> Product { get; set; }
        public DbSet<Manufacturer> Manufacturer { get; set; }
        public DbSet<Cart> Cart { get; set; }
        public DbSet<CartProduct> CartProduct { get; set; }
    }
}
