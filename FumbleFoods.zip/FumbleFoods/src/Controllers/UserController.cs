﻿using FumbleBE.src.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using poggers.src.Models;

namespace FumbleBE.src.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly FumbleDbContext _context;

        public UserController(FumbleDbContext context)
        {
            _context = context;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {

            _context.User.Add(user);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Registration successful" });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UserLoginModel model)
        {
            var user = await _context.User.SingleOrDefaultAsync(u => u.email == model.Email && u.password == model.Password);
            if (user == null)
            {
                return NotFound(new { message = "Invalid email or password" });
            }

            return Ok(user);
        }
    }
}
