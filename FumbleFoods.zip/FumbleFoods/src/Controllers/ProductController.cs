﻿using FumbleBE.src.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FumbleFoods.src.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly FumbleDbContext _context;

        public ProductController(FumbleDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            return await _context.Product.ToListAsync();
        }

        [HttpGet("category/{category}", Name = "GetProductsByCategory")]
        public async Task<ActionResult<IEnumerable<Product>>> GetProductsByCategory(string category)
        {
            var products = await _context.Product
                .Where(p => p.category.ToLower() == category.ToLower())
                .ToListAsync();

            if (!products.Any())
            {
                return NotFound(new { message = "No products found for the specified category" });
            }
            return Ok(products);
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            var product = await _context.Product
                .Include(p => p.manufacturer)
                .FirstOrDefaultAsync(p => p.productId == id);

            if (product == null)
            {
                return NotFound();
            }

            return Ok(new
            {
                ProductId = product.productId,
                ProductName = product.productName,
                Description = product.description,
                Dimensions = product.dimensions,
                Weight = product.weight,
                Rating = product.rating,
                SKU = product.SKU,
                Inventory = product.inventory,
                Cost = product.cost,
                Image = product.image,
                Category = product.category,
                Manufacturer = new
                {
                    ManufacturerId = product.manufacturer.manufacturerId,
                    ManufacturerName = product.manufacturer.name,
                    AboutSeller = product.manufacturer.description
                }
            });
        }





        [HttpPost]
        public async Task<ActionResult<Product>> PostProduct(Product product)
        {
            _context.Product.Add(product);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetProduct", new { id = product.productId }, product);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, Product product)
        {
            if (id != product.productId)
            {
                return BadRequest();
            }

            _context.Entry(product).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _context.Product.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            _context.Product.Remove(product);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ProductExists(int id)
        {
            return _context.Product.Any(e => e.productId == id);
        }
    }
}

