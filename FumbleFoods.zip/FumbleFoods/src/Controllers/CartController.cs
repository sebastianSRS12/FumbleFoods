﻿using FumbleBE.src.Data;
using FumbleFoods.src.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FumbleBE.src.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly FumbleDbContext _context;

        public CartController(FumbleDbContext context)
        {
            _context = context;
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddToCart([FromBody] CartProductModel model)
        {
            // Get the user's cart
            var cart = await _context.Cart
                .Include(c => c.CartProducts)
                .SingleOrDefaultAsync(c => c.UserId == model.UserId);

            if (cart == null)
            {
                return NotFound(new { message = "Cart not found for the user" });
            }

            var existingCartProduct = cart.CartProducts.FirstOrDefault(cp => cp.ProductId == model.ProductId);

            if (existingCartProduct != null)
            {
                existingCartProduct.Quantity += model.Quantity;
            }
            else
            {
                var cartProduct = new CartProduct
                {
                    CartId = cart.CartId,
                    ProductId = model.ProductId,
                    Quantity = model.Quantity
                };
                cart.CartProducts.Add(cartProduct);
            }

            await _context.SaveChangesAsync();

            return Ok(new { message = "Product added to cart" });
        }

        [HttpDelete("remove/{cartProductId}")]
        public async Task<IActionResult> RemoveFromCart(int cartProductId)
        {
            var cartProduct = await _context.CartProduct.FindAsync(cartProductId);

            if (cartProduct == null)
            {
                return NotFound(new { message = "CartProduct not found" });
            }

            _context.CartProduct.Remove(cartProduct);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Product removed from cart" });
        }

        [HttpGet("products/{userId}")]
        public async Task<IActionResult> GetCartProducts(int userId)
        {
            var cart = await _context.Cart
                .Include(c => c.CartProducts)
                .ThenInclude(cp => cp.Product)
                .SingleOrDefaultAsync(c => c.UserId == userId);

            if (cart == null)
            {
                return NotFound(new { message = "Cart not found for the user" });
            }

            var cartProducts = cart.CartProducts.Select(cp => new
            {
                CartProductId = cp.CartProductId,
                ProductId = cp.ProductId,
                ProductName = cp.Product.productName,
                Cost = cp.Product.cost,
                Quantity = cp.Quantity,
                Image = cp.Product.image
            });

            return Ok(cartProducts);
        }
    }
}
