using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FumbleFoods.src
{
    public class CartManager : ICartManager
    {
        public void DisplayCartItems(string userId) {
            return;
        }
    }
}