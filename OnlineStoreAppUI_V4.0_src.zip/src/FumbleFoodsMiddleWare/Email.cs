using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace FumbleFoods.src
{
    public class Email
    {
        public int EmailId { get; set; }
        public string EmailAddress { get; set; }
        public int UserId { get; set; }
    }
}