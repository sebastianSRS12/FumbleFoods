using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FumbleFoods.src
{
    public class CartEngine : ICartEngine
    {
        public long GetTotalProductPrice(int cartId) {
            long totalPrice = 0;
            return totalPrice;
        }
    }
}