namespace FumbleFoods.src
{
    public interface ICartManager
    {
        long GetTotalProductPrice(int cartId);
    }
}