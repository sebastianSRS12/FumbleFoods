namespace FumbleFoods.src
{
    public interface ICartManager
    {
        void DisplayCartItems(string userId);
    }
}