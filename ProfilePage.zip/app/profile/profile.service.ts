import { Injectable } from '@angular/core';
import { ProfileOption } from './profile-option.model';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  getProfileOptions(): ProfileOption[] {
    return [
      { title: 'Your Orders', description: 'Track, return, or cancel an order', icon: 'shopping_cart', link: '/orders' },
      // room for more options
    ];
  }
}
