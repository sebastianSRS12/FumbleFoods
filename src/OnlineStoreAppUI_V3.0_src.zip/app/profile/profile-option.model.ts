export interface ProfileOption {
  title: string;
  description: string;
  icon: string;
  link: string; // possible router/external link
}
