export * from './productDetail.component';
