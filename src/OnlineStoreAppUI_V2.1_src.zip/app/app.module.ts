import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { homeComponent } from './home';
import { loginComponent } from './login';
import { registerComponent } from './register';
import { ProfileModule } from './profile/profile.module';
import { checkoutComponent } from './checkout';
import { cartComponent } from './cart';
import { AppRoutingModule } from './app-routing.module';


@NgModule({
  declarations: [
    AppComponent,
    homeComponent,
    loginComponent,
    registerComponent,
    checkoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ProfileModule,
    cartComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }



