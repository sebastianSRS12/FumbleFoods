export interface Feature {
  id: string;
  label: string;
  imagePath: string;
  link: string;
}
