import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { Product } from '../../models/product.model';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];

  constructor(private productService: ProductService, private router: Router) {}

  ngOnInit() {
    this.fetchProducts();
  }

  fetchProducts() {
    this.productService.getProducts().subscribe(
      (products) => {
        this.products = products;
        this.filteredProducts = products;
      },
      (error) => {
        console.error('Error fetching products:', error);
      }
    );
  }

  goToProduct(productId: number): void {
    this.router.navigate(['/product/' + productId]);
  }

  filterProductsByCategory(category: string) {
    this.productService.getProductsByCategory(category).subscribe(
      (products) => {
        this.filteredProducts = products;
      },
      (error) => {
        console.error('Error fetching products by category:', error);
      }
    );
  }
  resetFilter() {
    this.filteredProducts = this.products;
  }
  
}
