import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  userLogin: any = { email: '', password: '' };
  errorMessage: string = '';
  isLoggedIn: boolean = false;

  constructor(private userService: UserService, private router: Router) { }

  login(userLogin: any) {
    this.userService.login(userLogin).subscribe(
      (user: any) => {
        localStorage.setItem('currentUser', JSON.stringify(user));
        console.log('Login successful');
        this.router.navigate(['/home']);
      },
      (error) => {
        console.error('Login failed', error);
      }
    );
  }

  goToHome() {
    this.router.navigate(['/home']);
  }

  goToRegister() {
    this.router.navigate(['/register']);
  }
}
