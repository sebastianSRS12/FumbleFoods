import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../../models/product.model';
import { ProductService } from '../../services/product.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  product!: Product;
  error: any;
  productId!: number;
  userId!: number;
  currentUser: any;

  constructor(
    private route: ActivatedRoute,
    private productService: ProductService,
    private cartService: CartService
  ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.productId = params['id'];
      this.fetchProductData(this.productId);
      const storedUser = localStorage.getItem('currentUser');
      this.currentUser = storedUser ? JSON.parse(storedUser) : null;
      this.userId = this.currentUser.userId
    });
  }

  fetchProductData(productId: number) {
    this.productService.getProduct(productId)
      .subscribe(
        (product: Product) => {
          this.product = product;
        },
        (error: HttpErrorResponse) => {
          this.error = error;
          console.error('Error fetching product:', error);
        }
      );
  }

  addToCart() {
    const quantity = 1;
    this.cartService.addToCart(this.userId, this.productId, quantity)
      .subscribe(
        response => {
          console.log(response);
        },
        error => {
          console.error('Error adding to cart:', error);
        }
      );
  }
  
}