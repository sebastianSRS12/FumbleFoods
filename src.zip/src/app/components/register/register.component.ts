import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  user: any = {};

  constructor(private userService: UserService, private router: Router) { }

  registerUser() {
    if (!this.validateForm()) {
      console.error('Please fill in all required fields.');
      return;
    }

    this.userService.register(this.user).subscribe(
      (response) => {
        console.log('Registration successful', response);
        this.goToLogin();
      },
      (error) => {
        console.error('Registration failed', error);
      }
    );
  }

  validateForm(): boolean {
    return (
      this.user.firstName &&
      this.user.lastName &&
      this.user.phone &&
      this.user.email &&
      this.user.password
    );
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }
}
