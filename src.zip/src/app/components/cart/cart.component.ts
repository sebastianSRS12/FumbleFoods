import { Component, OnInit } from '@angular/core';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartProducts: any[] = [];
  userId!: number;
  currentUser: any;
  totalCost: number = 0;
  total: number = 0;
  taxes: number = 0;
  subtotal: number = 0;

  constructor(
    private cartService: CartService,
  ) { }

  ngOnInit() {
    const storedUser = localStorage.getItem('currentUser');
    this.currentUser = storedUser ? JSON.parse(storedUser) : null;
    this.userId = this.currentUser.userId;
    this.fetchCartProducts();
  }

  fetchCartProducts() {
    this.cartService.getCartProducts(this.userId)
      .subscribe(
        (cartProducts) => {
          this.cartProducts = cartProducts;
          this.calculateTotalCost();
        },
        (error) => {
          console.error('Error fetching cart products:', error);
        }
      );
  }

  calculateTotalCost() {
    this.subtotal = this.cartProducts.reduce((total, cartProduct) => {
      const itemCost = cartProduct.cost * cartProduct.quantity;
      return total + itemCost;
    }, 0);
  
    const taxRate = 0.07;
    this.taxes = this.subtotal * taxRate;
    this.total = this.subtotal + this.taxes;
  }
  
}
