export interface Manufacturer {
    manufacturerId: number,
    manufacturerName: string,
    aboutSeller: string
  }
  