import { Manufacturer } from "./manufacturer";

export interface Product {
    productId: number;
    productName: string;
    description: string;
    manufacturer: Manufacturer;
    cost: number;
    image: string;
    weight: number;
    rating: number;
    sku: string;
    dimensions: string;
    inventory: number;
  }
  