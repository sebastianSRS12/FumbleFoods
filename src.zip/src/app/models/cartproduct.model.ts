export interface CartProduct {
  cartProductId: number;
  productId: number;
  productName: string;
  cost: number;
  quantity: number;
  image: string;
}
