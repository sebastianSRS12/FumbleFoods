import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private apiUrl = 'https://localhost:8000/api/Cart';

  constructor(private http: HttpClient) { }

  addToCart(userId: number, productId: number, quantity: number): Observable<any> {
    const url = `${this.apiUrl}/add`;
    const body = { userId, productId, quantity };
    return this.http.post(url, body);
  }

  getCartProducts(userId: number): Observable<any[]> {
    const url = `${this.apiUrl}/products/${userId}`;
    return this.http.get<any[]>(url);
  }

  private cartItems = new BehaviorSubject<any[]>([]);
  cartItems$ = this.cartItems.asObservable();

  removeFromCart(index: number) {
    const currentItems = this.cartItems.getValue();
    currentItems.splice(index, 1);
    this.cartItems.next([...currentItems]);
  }

  getCartItems() {
    return this.cartItems.getValue();
  }
}
